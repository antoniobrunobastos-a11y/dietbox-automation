#!/usr/bin/env python3
"""
Teste da Service Account do Google Sheets
"""

import os
from dotenv import load_dotenv

load_dotenv()

def test_service_account():
    """Testa Service Account"""
    try:
        print("🔐 Testando Service Account...")
        
        from src.google_sheets_service import GoogleSheetsService
        
        sheets_service = GoogleSheetsService()
        sheets_service.authenticate()
        
        print("✅ Service Account autenticada!")
        
        # Teste de leitura
        data = sheets_service.read_data()
        print(f"📊 {len(data)} registros lidos da planilha")
        
        if data:
            print(f"🎯 Primeiro registro: {data[0].get('Nome', 'Sem nome')}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        print("\n💡 Configure Service Account seguindo service_account_guide.md")
        return False

if __name__ == "__main__":
    test_service_account()