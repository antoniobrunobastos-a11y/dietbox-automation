import os
import sys
import logging
from dotenv import load_dotenv
from src.google_sheets_reader import GoogleSheetsReader
from src.dietbox_automation import DietBoxAutomation
from src.data_mapper import DataMapper

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('automation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

def main():
    try:
        logger.info("Iniciando automação DietBox...")
        
        # Inicializar componentes
        sheets_reader = GoogleSheetsReader()
        dietbox_automation = DietBoxAutomation()
        data_mapper = DataMapper()
        
        # Ler dados do Google Sheets
        logger.info("Lendo dados do Google Sheets...")
        sheet_data = sheets_reader.read_data()
        
        if not sheet_data:
            logger.warning("Nenhum dado encontrado na planilha")
            return
        
        # Fazer login no DietBox
        logger.info("Fazendo login no DietBox...")
        dietbox_automation.login()
        
        # Processar cada linha de dados
        success_count = 0
        error_count = 0
        
        for index, row_data in enumerate(sheet_data, 1):
            try:
                logger.info(f"Processando linha {index}...")
                
                # Mapear dados da planilha para formato DietBox
                mapped_data = data_mapper.map_anamnese_data(row_data)
                
                # Inserir dados no DietBox
                dietbox_automation.insert_anamnese(mapped_data)
                
                success_count += 1
                logger.info(f"Linha {index} processada com sucesso")
                
            except Exception as e:
                error_count += 1
                logger.error(f"Erro ao processar linha {index}: {str(e)}")
                continue
        
        logger.info(f"Automação concluída! Sucessos: {success_count}, Erros: {error_count}")
        
    except Exception as e:
        logger.error(f"Erro geral na automação: {str(e)}")
    finally:
        if 'dietbox_automation' in locals():
            dietbox_automation.close()

if __name__ == "__main__":
    main()