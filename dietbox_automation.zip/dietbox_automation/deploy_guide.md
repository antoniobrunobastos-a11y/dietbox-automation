# 🚀 Guia de Deploy - DietBox Automation Web

## 🌐 Deploy no Heroku (Gratuito)

### 1. Preparar o Projeto

```bash
# Instalar dependências
pip install -r requirements_web.txt

# Testar localmente
python web_app.py
# Acesse: http://localhost:5000
```

### 2. Deploy no Heroku

```bash
# Instalar Heroku CLI
# https://devcenter.heroku.com/articles/heroku-cli

# Login no Heroku
heroku login

# Criar app
heroku create dietbox-automation-[SEU-NOME]

# Configurar variáveis de ambiente
heroku config:set SECRET_KEY="sua-chave-secreta-aqui"
heroku config:set DIETBOX_EMAIL="larahnobreganutri@gmail.com"
heroku config:set DIETBOX_PASSWORD="mariaseca08#"
heroku config:set GOOGLE_SHEETS_ID="1xVv5INa_neG0MM3QUwnhres9Rttq5SlNq0kLHNs68Qs"
heroku config:set GOOGLE_SHEETS_RANGE="Anamnese!A:Z"

# Deploy
git init
git add .
git commit -m "Deploy DietBox Automation"
heroku git:remote -a dietbox-automation-[SEU-NOME]
git push heroku main
```

### 3. Configurar Google Sheets

```bash
# Upload das credenciais Google
heroku config:set GOOGLE_CREDENTIALS="$(cat credentials.json | base64)"
```

## 🌟 Deploy no Railway (Recomendado)

### 1. Criar conta no Railway

1. Acesse: https://railway.app
2. Conecte com GitHub
3. Faça fork do projeto ou suba os arquivos

### 2. Deploy Automático

1. **Connect Repository** no Railway
2. **Configure variáveis de ambiente:**
   - `SECRET_KEY`: chave secreta
   - `DIETBOX_EMAIL`: larahnobreganutri@gmail.com  
   - `DIETBOX_PASSWORD`: mariaseca08#
   - `GOOGLE_SHEETS_ID`: 1xVv5INa_neG0MM3QUwnhres9Rttq5SlNq0kLHNs68Qs
   - `GOOGLE_SHEETS_RANGE`: Anamnese!A:Z

3. **Deploy automático!** 🎉

## 📱 Como Usar a Aplicação Web

### 🏠 Landing Page
- **URL**: https://seu-app.herokuapp.com
- **Recursos**:
  - Apresentação da automação
  - Verificação de conexão com Google Sheets
  - Detecção de novos registros
  - Botão para iniciar automação

### 📊 Dashboard
- **URL**: https://seu-app.herokuapp.com/dashboard
- **Recursos**:
  - Monitoramento em tempo real
  - Progresso da automação
  - Logs ao vivo
  - Estatísticas de processamento
  - Lista de registros processados
  - Ações de controle (pausar, parar, relatório)

## 🔧 Configuração de Produção

### Variáveis de Ambiente Necessárias:

```env
# Aplicação
SECRET_KEY=sua-chave-secreta-super-segura

# DietBox
DIETBOX_EMAIL=larahnobreganutri@gmail.com
DIETBOX_PASSWORD=mariaseca08#
DIETBOX_URL=https://dietbox.me

# Google Sheets
GOOGLE_SHEETS_ID=1xVv5INa_neG0MM3QUwnhres9Rttq5SlNq0kLHNs68Qs
GOOGLE_SHEETS_RANGE=Anamnese!A:Z

# Opcional
HEADLESS_MODE=True
WAIT_TIMEOUT=10
```

### Credenciais Google:
- Faça upload do arquivo `credentials.json`
- Ou configure como base64 na variável `GOOGLE_CREDENTIALS`

## 🚀 Funcionalidades da Web App

### ✅ Landing Page Responsiva
- Design moderno com Tailwind CSS
- Verificação automática de conexão
- Detecção de novos dados
- Call-to-action para iniciar automação

### ✅ Dashboard em Tempo Real
- **WebSocket** para atualizações instantâneas
- **Barra de progresso** animada
- **Logs ao vivo** com cores
- **Estatísticas** detalhadas
- **Registros processados** com status

### ✅ Monitoramento Inteligente
- **Detecção automática** de novos dados na planilha
- **Status em tempo real** da automação
- **Contadores** de sucessos e erros
- **Tempo decorrido** e velocidade média

### ✅ Interface Responsiva
- **Mobile-first** design
- **Icons** do FontAwesome
- **Animações** suaves
- **Feedback visual** para todas as ações

## 📋 Checklist de Deploy

- [ ] Criar conta na plataforma (Heroku/Railway)
- [ ] Configurar variáveis de ambiente
- [ ] Fazer upload das credenciais Google
- [ ] Testar conexão com Google Sheets
- [ ] Executar primeira automação de teste
- [ ] Compartilhar link com equipe
- [ ] Configurar domínio personalizado (opcional)

## 🔗 URLs de Exemplo

- **Landing**: https://dietbox-automation.herokuapp.com
- **Dashboard**: https://dietbox-automation.herokuapp.com/dashboard
- **API Status**: https://dietbox-automation.herokuapp.com/api/status
- **API Check**: https://dietbox-automation.herokuapp.com/api/check-sheets

## 💡 Próximos Passos

1. **Deploy** na nuvem
2. **Teste** com dados reais
3. **Compartilhe** o link com a equipe
4. **Execute** automações diárias
5. **Economize** 2-4 horas por dia! 🎯

---

**🎉 Sua automação está pronta para o mundo!**