#!/usr/bin/env python3
"""
Script de configuração inicial da automação DietBox
"""

import os
import sys
import subprocess
import json

def install_dependencies():
    """Instala dependências do projeto"""
    print("📦 Instalando dependências...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Dependências instaladas com sucesso!")
    except subprocess.CalledProcessError:
        print("❌ Erro ao instalar dependências")
        sys.exit(1)

def create_env_file():
    """Cria arquivo .env baseado no exemplo"""
    if not os.path.exists('.env'):
        if os.path.exists('.env.example'):
            print("📝 Criando arquivo .env...")
            with open('.env.example', 'r') as example:
                content = example.read()
            
            with open('.env', 'w') as env_file:
                env_file.write(content)
            
            print("✅ Arquivo .env criado! Configure suas credenciais antes de executar.")
        else:
            print("❌ Arquivo .env.example não encontrado")
    else:
        print("ℹ️  Arquivo .env já existe")

def setup_google_credentials():
    """Instruções para configurar credenciais Google"""
    print("\n📋 CONFIGURAÇÃO GOOGLE SHEETS API:")
    print("1. Acesse: https://console.developers.google.com/")
    print("2. Crie um novo projeto ou selecione um existente")
    print("3. Ative a API Google Sheets")
    print("4. Crie credenciais (OAuth 2.0)")
    print("5. Baixe o arquivo JSON e renomeie para 'credentials.json'")
    print("6. Coloque o arquivo na raiz do projeto")
    
    if not os.path.exists('credentials.json'):
        print("⚠️  Arquivo credentials.json não encontrado!")
        print("   Execute novamente após configurar as credenciais.")

def create_sample_config():
    """Cria arquivo de configuração de exemplo"""
    config = {
        "field_mapping": {
            "Nome": "nome_paciente",
            "Email": "email",
            "Telefone": "telefone",
            "Data de Nascimento": "data_nascimento",
            "Peso": "peso",
            "Altura": "altura",
            "Objetivo": "objetivo"
        },
        "dietbox_selectors": {
            "email_field": "#email",
            "password_field": "#password",
            "login_button": "button[type='submit']",
            "anamnese_link": "a[href*='anamnese']",
            "new_button": "button:contains('Nova')",
            "save_button": "button:contains('Salvar')"
        },
        "automation_settings": {
            "wait_timeout": 10,
            "retry_attempts": 3,
            "delay_between_actions": 1
        }
    }
    
    with open('config.json', 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    
    print("✅ Arquivo config.json criado!")

def main():
    print("🚀 CONFIGURAÇÃO DA AUTOMAÇÃO DIETBOX")
    print("=" * 40)
    
    # Instalar dependências
    install_dependencies()
    
    # Criar arquivo .env
    create_env_file()
    
    # Configurar Google credentials
    setup_google_credentials()
    
    # Criar configuração de exemplo
    create_sample_config()
    
    print("\n✨ CONFIGURAÇÃO CONCLUÍDA!")
    print("\n📝 PRÓXIMOS PASSOS:")
    print("1. Configure o arquivo .env com suas credenciais")
    print("2. Adicione o arquivo credentials.json do Google")
    print("3. Ajuste o mapeamento de campos em config.json")
    print("4. Execute: python main.py")
    
    print("\n⚠️  IMPORTANTE:")
    print("- Teste primeiro com poucos registros")
    print("- Verifique os seletores CSS do DietBox")
    print("- Mantenha backup dos seus dados")

if __name__ == "__main__":
    main()