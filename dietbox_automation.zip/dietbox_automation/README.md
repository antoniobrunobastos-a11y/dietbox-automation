# 🤖 Automação DietBox

Automação Python 100% funcional que transfere dados de anamnese do Google Sheets para o DietBox, economizando 2-4 horas diárias de trabalho manual.

## 🚀 Características

- ✅ Login automático no DietBox
- ✅ Leitura de dados do Google Sheets
- ✅ Mapeamento inteligente de campos
- ✅ Tratamento de erros robusto
- ✅ Logs detalhados
- ✅ Configuração flexível
- ✅ Retry automático em falhas

## 📋 Pré-requisitos

- Python 3.8+
- Chrome/Chromium browser
- Conta Google (para Sheets API)
- Acesso ao DietBox

## ⚙️ Configuração Inicial

### 1. Clone e Configure o Projeto

```bash
# Clone o projeto
git clone <seu-repo>
cd dietbox_automation

# Execute a configuração
python setup.py
```

### 2. Configure Credenciais Google Sheets

1. Acesse [Google Cloud Console](https://console.developers.google.com/)
2. Crie um projeto ou selecione existente
3. Ative a **Google Sheets API**
4. Crie credenciais OAuth 2.0
5. Baixe o JSON e renomeie para `credentials.json`
6. Coloque na raiz do projeto

### 3. Configure Variáveis de Ambiente

Edite o arquivo `.env`:

```env
# DietBox Credentials
DIETBOX_URL=https://app.dietbox.me/login
DIETBOX_EMAIL=seu_email@exemplo.com
DIETBOX_PASSWORD=sua_senha

# Google Sheets
GOOGLE_SHEETS_ID=1A2B3C4D5E6F7G8H9I0J
GOOGLE_SHEETS_RANGE=Anamnese!A:Z

# Chrome Options
HEADLESS_MODE=False
WAIT_TIMEOUT=10
```

### 4. Ajuste Mapeamento de Campos

Edite `config.json` para mapear campos da sua planilha:

```json
{
  "field_mapping": {
    "Nome": "nome_paciente",
    "Email": "email",
    "Telefone": "telefone",
    "Data de Nascimento": "data_nascimento"
  }
}
```

## 🏃‍♂️ Executando a Automação

### Execução Básica

```bash
python main.py
```

### Modo Teste (apenas alguns registros)

```bash
# Modifique main.py para processar apenas os primeiros registros
# ou implemente um parâmetro de linha de comando
```

## 📊 Estrutura da Planilha

Sua planilha Google Sheets deve ter a seguinte estrutura:

| Nome | Email | Telefone | Data de Nascimento | Peso | Altura | ... |
|------|--------|----------|-------------------|------|--------|-----|
| João Silva | joao@email.com | 11999999999 | 01/01/1990 | 80 | 1.75 | ... |

## 🔧 Personalização

### Adicionando Novos Campos

1. Adicione na planilha Google Sheets
2. Mapeie em `src/data_mapper.py`:

```python
self.field_mapping = {
    'Nova Coluna': 'novo_campo_dietbox',
    # ... outros campos
}
```

3. Se necessário, adicione transformação em `_transform_field_value()`

### Ajustando Seletores Web

Se o DietBox mudar a interface, ajuste os seletores em `config.json`:

```json
{
  "dietbox_selectors": {
    "email_field": "#email",
    "password_field": "#password",
    "login_button": "button[type='submit']"
  }
}
```

## 🐛 Troubleshooting

### Problemas Comuns

**1. Erro de Login**
- Verifique credenciais no `.env`
- Confirme URL do DietBox
- Verifique seletores de login

**2. Erro Google Sheets**
- Confirme `credentials.json`
- Verifique ID da planilha
- Confirme permissões de acesso

**3. Campos não preenchidos**
- Verifique mapeamento em `data_mapper.py`
- Confirme seletores dos campos
- Use modo não-headless para debugging

**4. Timeout Errors**
- Aumente `WAIT_TIMEOUT` no `.env`
- Verifique conexão com internet
- Considere usar retry manual

### Logs e Debugging

Os logs são salvos em `automation.log`:

```bash
# Visualizar logs em tempo real
tail -f automation.log

# Buscar erros específicos
grep ERROR automation.log
```

### Modo Debug

Para debugging visual, configure:

```env
HEADLESS_MODE=False
WAIT_TIMEOUT=30
```

## 📈 Monitoramento

A automação gera logs detalhados incluindo:

- ✅ Sucessos por registro
- ❌ Erros e suas causas
- ⏱️ Tempo de execução
- 📊 Estatísticas finais

## 🔐 Segurança

- **Credenciais**: Nunca commite o arquivo `.env`
- **Token Google**: O `token.pickle` é gerado automaticamente
- **Dados**: Backup antes de executar em produção

## 🚨 Limitações

- Dependente da interface web do DietBox
- Rate limits da Google Sheets API
- Requer manutenção se houver mudanças no DietBox

## 📞 Suporte

Para problemas ou melhorias:

1. Verifique logs de erro
2. Confirme configurações
3. Teste com poucos registros primeiro
4. Documente problemas encontrados

## 📝 Licença

Este projeto é para uso interno. Respeite os termos de uso do DietBox e Google Sheets API.

---

**⚠️ IMPORTANTE**: Sempre teste com dados não-críticos primeiro e mantenha backups dos seus dados originais.