#!/usr/bin/env python3
"""
Script de debug para analisar o login do DietBox
"""

import os
import time
from dotenv import load_dotenv
from src.dietbox_automation import DietBoxAutomation

load_dotenv()

def debug_login():
    """Debug do processo de login mantendo navegador aberto"""
    print("🔍 DEBUG - Login DietBox")
    
    automation = DietBoxAutomation()
    
    try:
        print("🌐 Acessando DietBox...")
        automation.driver.get("https://dietbox.me")
        
        # Aguarda redirecionamento
        time.sleep(5)
        
        print(f"📍 URL atual: {automation.driver.current_url}")
        print(f"📄 Título da página: {automation.driver.title}")
        
        # Tenta encontrar diferentes elementos de login
        print("\n🔍 Procurando elementos de login...")
        
        # Email fields
        email_selectors = ["#email", "input[type='email']", "[name='email']", "#signInName"]
        for selector in email_selectors:
            try:
                elements = automation.driver.find_elements("css selector", selector)
                if elements:
                    element = elements[0]
                    print(f"✅ Email field encontrado: {selector}")
                    print(f"   - Visível: {element.is_displayed()}")
                    print(f"   - Habilitado: {element.is_enabled()}")
                    print(f"   - Tag: {element.tag_name}")
                    print(f"   - Type: {element.get_attribute('type')}")
            except:
                pass
        
        # Password fields  
        password_selectors = ["#password", "input[type='password']", "[name='password']"]
        for selector in password_selectors:
            try:
                elements = automation.driver.find_elements("css selector", selector)
                if elements:
                    element = elements[0]
                    print(f"✅ Password field encontrado: {selector}")
                    print(f"   - Visível: {element.is_displayed()}")
                    print(f"   - Habilitado: {element.is_enabled()}")
            except:
                pass
        
        # Buttons
        button_selectors = ["button", "input[type='submit']", "input[type='button']"]
        for selector in button_selectors:
            try:
                elements = automation.driver.find_elements("css selector", selector)
                for i, element in enumerate(elements[:3]):  # Só os 3 primeiros
                    text = element.text or element.get_attribute('value') or element.get_attribute('title')
                    print(f"🔘 Botão {i+1}: {text} ({selector})")
            except:
                pass
        
        print(f"\n⏱️  Mantendo navegador aberto por 30 segundos para inspeção...")
        print("🔍 Inspect na página para ver os elementos!")
        
        # Aguarda para inspeção manual
        time.sleep(30)
        
    except Exception as e:
        print(f"❌ Erro: {e}")
    finally:
        automation.close()

if __name__ == "__main__":
    debug_login()