#!/usr/bin/env python3
"""
Aplicação Web para Automação DietBox
Landing Page + Dashboard em tempo real
"""

from flask import Flask, render_template, jsonify, request, session
from flask_socketio import SocketIO, emit
import os
import json
import time
import threading
import base64
from datetime import datetime, timedelta
from dotenv import load_dotenv
try:
    from src.google_sheets_service import GoogleSheetsService as GoogleSheetsReader
except ImportError:
    from src.google_sheets_reader import GoogleSheetsReader
from src.data_mapper import DataMapper
import uuid

load_dotenv()

# Handle service account JSON for production
if os.getenv('GOOGLE_APPLICATION_CREDENTIALS_JSON'):
    try:
        # Decode base64 encoded service account JSON
        service_account_info = base64.b64decode(os.getenv('GOOGLE_APPLICATION_CREDENTIALS_JSON'))
        with open('service-account.json', 'wb') as f:
            f.write(service_account_info)
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'service-account.json'
    except Exception as e:
        print(f"Warning: Could not decode service account JSON: {e}")

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dietbox-automation-secret-key')
socketio = SocketIO(app, cors_allowed_origins="*")

# Storage em memória para dados da sessão
automation_sessions = {}
processed_records = {}

class AutomationSession:
    def __init__(self, session_id):
        self.session_id = session_id
        self.status = 'idle'  # idle, running, completed, error
        self.progress = 0
        self.total_records = 0
        self.processed_count = 0
        self.success_count = 0
        self.error_count = 0
        self.current_record = None
        self.logs = []
        self.start_time = None
        self.end_time = None
        self.last_check_time = datetime.now()
    
    def add_log(self, message, level="info"):
        log_entry = {
            'timestamp': datetime.now().strftime('%H:%M:%S'),
            'level': level,
            'message': message
        }
        self.logs.append(log_entry)
        
        # Emit para clientes WebSocket
        socketio.emit('log_update', {
            'session_id': self.session_id,
            'log': log_entry
        })
    
    def update_progress(self, processed, total, current_record=None):
        self.processed_count = processed
        self.total_records = total
        self.progress = (processed / total * 100) if total > 0 else 0
        self.current_record = current_record
        
        # Emit progresso para clientes
        socketio.emit('progress_update', {
            'session_id': self.session_id,
            'progress': self.progress,
            'processed': processed,
            'total': total,
            'current_record': current_record
        })

@app.route('/')
def landing_page():
    """Landing page principal"""
    return render_template('landing.html')

@app.route('/health')
def health_check():
    """Health check endpoint for Render"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@app.route('/dashboard')
def dashboard():
    """Dashboard de automação"""
    return render_template('dashboard.html')

@app.route('/api/status')
def get_status():
    """API para obter status da automação"""
    session_id = session.get('automation_session_id')
    if not session_id or session_id not in automation_sessions:
        return jsonify({
            'status': 'idle',
            'message': 'Nenhuma sessão ativa'
        })
    
    automation_session = automation_sessions[session_id]
    return jsonify({
        'session_id': session_id,
        'status': automation_session.status,
        'progress': automation_session.progress,
        'processed': automation_session.processed_count,
        'total': automation_session.total_records,
        'success': automation_session.success_count,
        'errors': automation_session.error_count,
        'current_record': automation_session.current_record,
        'start_time': automation_session.start_time.isoformat() if automation_session.start_time else None,
        'logs': automation_session.logs[-10:]  # Últimos 10 logs
    })

@app.route('/api/check-sheets')
def check_sheets():
    """Verifica conexão e dados do Google Sheets"""
    try:
        sheets_reader = GoogleSheetsReader()
        
        # Testa conexão
        sheets_reader.authenticate()
        
        # Lê dados
        data = sheets_reader.read_data()
        headers = sheets_reader.get_headers()
        
        # Verifica novos dados (últimas 24h - simulação)
        new_count = len([r for r in data if 'Data' in r and r['Data']])  # Exemplo
        
        return jsonify({
            'success': True,
            'total_records': len(data),
            'new_records': min(new_count, 3),  # Simula novos registros
            'headers': headers,
            'sample_data': data[:3] if data else [],
            'last_updated': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

@app.route('/api/start-automation', methods=['POST'])
def start_automation():
    """Inicia processo de automação"""
    try:
        # Criar nova sessão
        session_id = str(uuid.uuid4())
        session['automation_session_id'] = session_id
        
        automation_session = AutomationSession(session_id)
        automation_sessions[session_id] = automation_session
        
        # Iniciar automação em thread separada
        thread = threading.Thread(
            target=run_automation_background,
            args=(automation_session,)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'message': 'Automação iniciada com sucesso!'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 400

def run_automation_background(automation_session):
    """Executa automação em background"""
    try:
        automation_session.status = 'running'
        automation_session.start_time = datetime.now()
        automation_session.add_log("🚀 Iniciando automação DietBox...")
        
        # Lê dados do Google Sheets
        automation_session.add_log("📊 Conectando ao Google Sheets...")
        sheets_reader = GoogleSheetsReader()
        sheets_reader.authenticate()
        
        data = sheets_reader.read_data()
        
        # Se não há dados reais, avisar
        if not data:
            automation_session.add_log("⚠️ Nenhum dado encontrado na planilha", "warning")
            automation_session.add_log("📝 Adicione dados na planilha Google Sheets para processar")
            automation_session.status = 'completed'
            return
        
        automation_session.total_records = len(data)
        automation_session.add_log(f"✅ {len(data)} registros encontrados para processamento")
        
        # Mapear dados
        data_mapper = DataMapper()
        automation_session.add_log("🔄 Processando dados...")
        
        for i, row_data in enumerate(data, 1):
            try:
                # Simula processamento
                automation_session.add_log(f"📝 Processando registro {i}: {row_data.get('Nome', 'Sem nome')}")
                automation_session.current_record = row_data.get('Nome', f'Registro {i}')
                
                # Mapear dados
                mapped_data = data_mapper.map_anamnese_data(row_data)
                
                # AUTOMAÇÃO REAL DO DIETBOX
                automation_session.add_log(f"🌐 Conectando ao DietBox para {row_data.get('Nome', f'Registro {i}')}")
                
                # AUTOMAÇÃO REAL ATIVADA
                try:
                    from src.dietbox_automation import DietBoxAutomation
                    dietbox = DietBoxAutomation()
                    dietbox.login()
                    dietbox.insert_anamnese(mapped_data)
                    dietbox.close()
                    automation_session.add_log(f"✅ Dados inseridos no DietBox com sucesso!")
                except Exception as e:
                    automation_session.add_log(f"❌ Erro DietBox: {str(e)}", "error")
                    automation_session.error_count += 1
                    # Em caso de erro, registra mas continua
                    processed_records[f"{automation_session.session_id}_{i}"] = {
                        'original': row_data,
                        'mapped': mapped_data,
                        'error': str(e),
                        'status': 'error',
                        'timestamp': datetime.now().isoformat()
                    }
                    continue
                
                time.sleep(3)  # Simula tempo real de processamento
                
                automation_session.success_count += 1
                automation_session.add_log(f"✅ Registro {i} processado com sucesso")
                
                # Atualiza progresso
                automation_session.update_progress(i, len(data), row_data.get('Nome', f'Registro {i}'))
                
                # Salva registro processado
                processed_records[f"{automation_session.session_id}_{i}"] = {
                    'original': row_data,
                    'mapped': mapped_data,
                    'status': 'success',
                    'timestamp': datetime.now().isoformat()
                }
                
            except Exception as e:
                automation_session.error_count += 1
                automation_session.add_log(f"❌ Erro no registro {i}: {str(e)}", "error")
                
                # Salva erro
                processed_records[f"{automation_session.session_id}_{i}"] = {
                    'original': row_data,
                    'error': str(e),
                    'status': 'error',
                    'timestamp': datetime.now().isoformat()
                }
        
        automation_session.status = 'completed'
        automation_session.end_time = datetime.now()
        duration = automation_session.end_time - automation_session.start_time
        
        automation_session.add_log(
            f"🎉 Automação concluída! {automation_session.success_count} sucessos, "
            f"{automation_session.error_count} erros em {duration.total_seconds():.1f}s"
        )
        
    except Exception as e:
        automation_session.status = 'error'
        automation_session.add_log(f"💥 Erro crítico na automação: {str(e)}", "error")

@app.route('/api/processed-records')
def get_processed_records():
    """Retorna registros processados"""
    session_id = session.get('automation_session_id')
    if not session_id:
        return jsonify([])
    
    # Filtra registros da sessão atual
    session_records = {
        k: v for k, v in processed_records.items() 
        if k.startswith(session_id)
    }
    
    return jsonify(list(session_records.values()))

@socketio.on('connect')
def handle_connect():
    """Cliente conectado via WebSocket"""
    session_id = session.get('automation_session_id')
    if session_id and session_id in automation_sessions:
        emit('session_restored', {'session_id': session_id})

@socketio.on('join_session')
def handle_join_session(data):
    """Cliente quer acompanhar uma sessão específica"""
    session_id = data.get('session_id')
    if session_id and session_id in automation_sessions:
        session['automation_session_id'] = session_id
        emit('joined_session', {'session_id': session_id})

if __name__ == '__main__':
    # Cria diretórios necessários
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    
    # Configuração para produção ou desenvolvimento
    port = int(os.getenv('PORT', 5001))
    debug = os.getenv('FLASK_ENV') != 'production'
    
    # Roda aplicação
    socketio.run(app, debug=debug, host='0.0.0.0', port=port)