#!/usr/bin/env python3
"""
Teste simplificado de Google Sheets com autenticação manual
"""

import os
import sys
from dotenv import load_dotenv
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import pickle

load_dotenv()

SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']

def main():
    print("🔐 Autenticação Google Sheets")
    
    # Verificar credenciais
    if not os.path.exists('credentials.json'):
        print("❌ credentials.json não encontrado!")
        return
    
    sheets_id = os.getenv('GOOGLE_SHEETS_ID')
    if not sheets_id:
        print("❌ GOOGLE_SHEETS_ID não configurado!")
        return
    
    print(f"📊 Planilha: {sheets_id}")
    
    try:
        # Tentar carregar token existente
        creds = None
        if os.path.exists('token.pickle'):
            with open('token.pickle', 'rb') as token:
                creds = pickle.load(token)
                print("✅ Token existente carregado")
        
        # Se não há credenciais válidas
        if not creds or not creds.valid:
            print("🌐 Executando autenticação...")
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            
            # Usar método que não depende de servidor local
            print("📋 Copiando URL de autorização...")
            auth_url, _ = flow.authorization_url(prompt='consent')
            
            print(f"\n🔗 Abra este link no seu navegador:")
            print(f"{auth_url}")
            print("\n📝 Após autorizar, copie o código da URL e cole aqui:")
            
            auth_code = input("Cole o código aqui: ").strip()
            
            flow.fetch_token(code=auth_code)
            creds = flow.credentials
            
            # Salvar token
            with open('token.pickle', 'wb') as token:
                pickle.dump(creds, token)
                print("✅ Token salvo!")
        
        # Testar Google Sheets
        service = build('sheets', 'v4', credentials=creds)
        
        # Ler dados da planilha
        result = service.spreadsheets().values().get(
            spreadsheetId=sheets_id,
            range='A1:Z1000'  # Range amplo para pegar todos os dados
        ).execute()
        
        values = result.get('values', [])
        
        if not values:
            print("⚠️  Planilha vazia")
        else:
            print(f"✅ {len(values)} linhas lidas!")
            print(f"📋 Cabeçalhos: {values[0] if values else 'Nenhum'}")
            
            if len(values) > 1:
                print(f"📄 Dados: {len(values) - 1} registros")
        
        print("\n🎉 TESTE CONCLUÍDO COM SUCESSO!")
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        return False

if __name__ == "__main__":
    main()