# 🚀 DietBox Automation - Guia Final de Uso

## 📱 Sua Aplicação está no Ar!

**URL da Aplicação:** `https://sua-app.onrender.com` *(substituir pela URL real)*

---

## 🔐 Como Usar:

### 1. **Acesse a Aplicação**
- Abra o link no navegador
- Qualquer pessoa com o link pode usar

### 2. **Tela Principal (Landing Page)**
- Clique **"Testar Conexão"** para verificar Google Sheets
- Clique **"Iniciar Dashboard"** para começar

### 3. **Dashboard de Automação**
- **Conectar Sheets**: Testa conexão com planilha
- **Iniciar Automação**: Processa todos os dados
- **Acompanhar**: Logs e progresso em tempo real

---

## 📊 Funcionamento:

### **Fluxo Automático:**
1. 🔍 **Lê dados** da planilha Google Sheets
2. 🔄 **Processa e mapeia** os dados
3. 🌐 **Conecta ao DietBox** automaticamente
4. 📝 **Insere anamnese** para cada paciente
5. ✅ **Confirma sucesso** ou reporta erros

### **Dados Processados:**
- Nome do paciente
- Email e telefone
- Peso, altura, idade
- Histórico médico
- Objetivos e preferências
- Informações complementares

---

## 🔧 Configuração da Planilha:

### **Google Sheets necessária:**
- **ID**: `1xVv5INa_neG0MM3QUwnhres9Rttq5SlNq0kLHNs68Qs`
- **Aba**: `Respostas ao formulário 1`
- **Compartilhada com**: `dietbox-automation@dietbox-automation.iam.gserviceaccount.com`

### **Colunas esperadas:**
- Nome
- Email  
- Telefone
- Peso
- Altura
- Idade
- Sexo
- Objetivo
- *(outras colunas do formulário)*

---

## 🎯 Credenciais Configuradas:

### **DietBox:**
- **URL**: https://dietbox.me
- **Email**: larahnobreganutri@gmail.com
- **Senha**: *(configurada)*

### **Google Sheets:**
- **Service Account**: Configurado
- **Acesso**: Somente leitura
- **Autenticação**: Automática

---

## 📈 Recursos da Aplicação:

### ✅ **Landing Page Profissional**
- Design responsivo
- Teste de conexão
- Estatísticas em tempo real

### ✅ **Dashboard Completo**
- Progresso visual
- Logs detalhados
- Status de cada registro
- Controle total do processo

### ✅ **Automação Real**
- Conecta ao DietBox real
- Insere dados automaticamente
- Tratamento de erros
- Retry automático

### ✅ **Tempo Real**
- WebSocket para atualizações
- Progresso instantâneo
- Logs ao vivo
- Status detalhado

---

## 🚨 Importante:

### **Segurança:**
- Credenciais protegidas
- Conexão HTTPS
- Service Account seguro

### **Performance:**
- Processa 1 registro por vez
- Aguarda 3s entre registros
- Modo headless no servidor

### **Monitoramento:**
- Health check: `/health`
- Status da aplicação
- Logs detalhados

---

## 📞 Suporte:

### **Problemas Comuns:**
1. **"Nenhum dado encontrado"**
   - Verifique se há dados na planilha
   - Confirme compartilhamento com service account

2. **"Erro de login DietBox"**
   - Verifique credenciais
   - Tente novamente em alguns minutos

3. **"Conexão perdida"**
   - Recarregue a página
   - Inicie nova sessão

### **Logs Detalhados:**
- Cada ação é registrada
- Erros são explicados
- Status completo disponível

---

## 🎉 Pronto para Uso!

Sua automação está **100% funcional** e no ar! 

- ✅ Economiza **2-4 horas diárias**
- ✅ Acesso **de qualquer lugar**
- ✅ Interface **profissional**
- ✅ **Automação real** do DietBox
- ✅ **Monitoramento** em tempo real

**Comece agora mesmo:** Acesse sua aplicação e clique em "Iniciar Automação"!