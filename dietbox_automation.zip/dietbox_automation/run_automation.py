#!/usr/bin/env python3
"""
Execução completa da automação DietBox
"""

import os
import sys
import logging
import time
from dotenv import load_dotenv

# Imports da automação
from src.dietbox_automation import DietBoxAutomation
from src.data_mapper import DataMapper

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('automation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

def test_dietbox_login():
    """Testa apenas o login no DietBox"""
    logger.info("🚀 TESTANDO LOGIN DIETBOX")
    
    try:
        # Verificar credenciais
        email = os.getenv('DIETBOX_EMAIL')
        password = os.getenv('DIETBOX_PASSWORD')
        
        if not email or not password:
            logger.error("❌ Credenciais DietBox não configuradas no .env")
            return False
        
        logger.info(f"📧 Email: {email}")
        
        # Inicializar automação
        automation = DietBoxAutomation()
        
        # Tentar login
        logger.info("🔐 Fazendo login...")
        automation.login()
        
        logger.info("✅ Login realizado com sucesso!")
        
        # Aguardar um pouco para verificar se ficou logado
        time.sleep(5)
        
        current_url = automation.driver.current_url
        logger.info(f"📍 URL atual: {current_url}")
        
        # Fechar navegador
        automation.close()
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro no teste de login: {str(e)}")
        if 'automation' in locals():
            automation.close()
        return False

def create_sample_data():
    """Cria dados de exemplo para testar mapeamento"""
    return [
        {
            'Nome': 'Maria Silva',
            'Email': 'maria@teste.com', 
            'Telefone': '11999999999',
            'Peso': '65 kg',
            'Altura': '1.65 m',
            'Objetivo': 'Emagrecimento'
        },
        {
            'Nome': 'João Santos',
            'Email': 'joao@teste.com',
            'Telefone': '11888888888', 
            'Peso': '80',
            'Altura': '175',
            'Objetivo': 'Ganho de massa'
        }
    ]

def test_data_mapping():
    """Testa o mapeamento de dados"""
    logger.info("🔄 TESTANDO MAPEAMENTO DE DADOS")
    
    try:
        mapper = DataMapper()
        sample_data = create_sample_data()
        
        for i, row in enumerate(sample_data, 1):
            logger.info(f"📋 Testando registro {i}:")
            mapped = mapper.map_anamnese_data(row)
            
            for field, value in mapped.items():
                logger.info(f"   {field}: {value}")
        
        logger.info("✅ Mapeamento funcionando!")
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro no mapeamento: {str(e)}")
        return False

def main():
    """Função principal"""
    print("🤖 AUTOMAÇÃO DIETBOX - TESTE COMPLETO")
    print("=" * 50)
    
    # Teste 1: Mapeamento de dados
    if not test_data_mapping():
        print("❌ Teste de mapeamento falhou")
        return
    
    # Teste 2: Login DietBox
    if not test_dietbox_login():
        print("❌ Teste de login falhou")
        return
    
    print("\n🎉 TODOS OS TESTES PASSARAM!")
    print("✅ A automação está pronta para uso")
    print("\n📋 PRÓXIMOS PASSOS:")
    print("1. Configure sua planilha Google Sheets")
    print("2. Ajuste o mapeamento de campos se necessário")
    print("3. Execute: python main.py")

if __name__ == "__main__":
    main()