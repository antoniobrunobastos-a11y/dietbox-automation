import os
import logging
from typing import List, Dict, Any
from google.oauth2 import service_account
from googleapiclient.discovery import build
import json

logger = logging.getLogger(__name__)

class GoogleSheetsService:
    """Service Account version - sem necessidade de OAuth do usuário"""
    
    SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']
    
    def __init__(self):
        self.service_account_file = 'service-account.json'
        self.sheets_id = os.getenv('GOOGLE_SHEETS_ID')
        self.sheets_range = os.getenv('GOOGLE_SHEETS_RANGE', 'Anamnese!A:Z')
        self.service = None
        
    def authenticate(self):
        """Autentica usando Service Account"""
        try:
            # Verifica se existe arquivo de service account
            if os.path.exists(self.service_account_file):
                credentials = service_account.Credentials.from_service_account_file(
                    self.service_account_file, scopes=self.SCOPES
                )
            else:
                # Tenta usar variável de ambiente
                service_account_info = os.getenv('GOOGLE_SERVICE_ACCOUNT')
                if service_account_info:
                    service_account_data = json.loads(service_account_info)
                    credentials = service_account.Credentials.from_service_account_info(
                        service_account_data, scopes=self.SCOPES
                    )
                else:
                    raise Exception("Credenciais de Service Account não encontradas")
            
            self.service = build('sheets', 'v4', credentials=credentials)
            logger.info("Autenticação Service Account realizada com sucesso")
            
        except Exception as e:
            logger.error(f"Erro na autenticação Service Account: {e}")
            # Fallback para o método OAuth original
            from .google_sheets_reader import GoogleSheetsReader
            oauth_reader = GoogleSheetsReader()
            oauth_reader.authenticate()
            self.service = oauth_reader.service
    
    def read_data(self) -> List[Dict[str, Any]]:
        """Lê dados da planilha"""
        if not self.service:
            self.authenticate()
        
        try:
            sheet = self.service.spreadsheets()
            result = sheet.values().get(
                spreadsheetId=self.sheets_id,
                range=self.sheets_range
            ).execute()
            
            values = result.get('values', [])
            
            if not values:
                logger.warning("Planilha está vazia")
                return []
            
            # Primeira linha como cabeçalhos
            headers = values[0]
            data_rows = values[1:]
            
            # Converte para lista de dicionários
            sheet_data = []
            for row in data_rows:
                # Preenche colunas vazias para manter consistência
                while len(row) < len(headers):
                    row.append('')
                
                row_dict = {headers[i]: row[i] for i in range(len(headers))}
                sheet_data.append(row_dict)
            
            logger.info(f"Lidos {len(sheet_data)} registros da planilha")
            return sheet_data
            
        except Exception as e:
            logger.error(f"Erro ao ler dados: {str(e)}")
            raise
    
    def get_headers(self) -> List[str]:
        """Retorna cabeçalhos da planilha"""
        if not self.service:
            self.authenticate()
        
        try:
            sheet = self.service.spreadsheets()
            result = sheet.values().get(
                spreadsheetId=self.sheets_id,
                range=f"{self.sheets_range.split('!')[0]}!1:1"
            ).execute()
            
            headers = result.get('values', [[]])[0]
            return headers
            
        except Exception as e:
            logger.error(f"Erro ao obter cabeçalhos: {str(e)}")
            raise