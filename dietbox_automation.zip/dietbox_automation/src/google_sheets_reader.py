import os
import logging
from typing import List, Dict, Any
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import pickle

logger = logging.getLogger(__name__)

class GoogleSheetsReader:
    SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']
    
    def __init__(self):
        self.credentials_file = 'credentials.json'
        self.token_file = 'token.pickle'
        self.sheets_id = os.getenv('GOOGLE_SHEETS_ID')
        self.sheets_range = os.getenv('GOOGLE_SHEETS_RANGE', 'Anamnese!A:Z')
        self.service = None
        
    def authenticate(self):
        """Autentica com Google Sheets API"""
        creds = None
        
        # Token já existe
        if os.path.exists(self.token_file):
            try:
                with open(self.token_file, 'rb') as token:
                    creds = pickle.load(token)
                logger.info("Token existente carregado")
            except Exception as e:
                logger.warning(f"Erro ao carregar token existente: {e}")
                # Remove token corrompido
                if os.path.exists(self.token_file):
                    os.remove(self.token_file)
                creds = None
        
        # Se não há credenciais válidas, faz login
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    logger.info("Renovando token expirado...")
                    creds.refresh(Request())
                except Exception as e:
                    logger.warning(f"Erro ao renovar token: {e}")
                    creds = None
            
            if not creds:
                if not os.path.exists(self.credentials_file):
                    raise FileNotFoundError(
                        f"Arquivo {self.credentials_file} não encontrado. "
                        "Baixe as credenciais do Google Cloud Console."
                    )
                
                logger.info("Iniciando fluxo de autenticação OAuth...")
                logger.info("Uma página do navegador será aberta para autenticação.")
                
                flow = InstalledAppFlow.from_client_secrets_file(
                    self.credentials_file, self.SCOPES)
                
                # Tenta diferentes portas se uma estiver ocupada
                ports_to_try = [8080, 8081, 8082, 0]
                creds = None
                
                for port in ports_to_try:
                    try:
                        logger.info(f"Tentando autenticação na porta {port}...")
                        creds = flow.run_local_server(
                            port=port,
                            open_browser=True,
                            access_type='offline',
                            prompt='consent'
                        )
                        break
                    except Exception as e:
                        logger.warning(f"Falha na porta {port}: {e}")
                        continue
                
                if not creds:
                    raise Exception("Não foi possível completar a autenticação")
            
            # Salva credenciais para próxima execução
            try:
                with open(self.token_file, 'wb') as token:
                    pickle.dump(creds, token)
                logger.info("Token salvo para futuras execuções")
            except Exception as e:
                logger.warning(f"Erro ao salvar token: {e}")
        
        self.service = build('sheets', 'v4', credentials=creds)
        logger.info("Autenticação com Google Sheets realizada com sucesso")
    
    def read_data(self) -> List[Dict[str, Any]]:
        """Lê dados da planilha Google Sheets"""
        if not self.service:
            self.authenticate()
        
        try:
            sheet = self.service.spreadsheets()
            result = sheet.values().get(
                spreadsheetId=self.sheets_id,
                range=self.sheets_range
            ).execute()
            
            values = result.get('values', [])
            
            if not values:
                logger.warning("Planilha está vazia")
                return []
            
            # Primeira linha como cabeçalhos
            headers = values[0]
            data_rows = values[1:]
            
            # Converte para lista de dicionários
            sheet_data = []
            for row in data_rows:
                # Preenche colunas vazias para manter consistência
                while len(row) < len(headers):
                    row.append('')
                
                row_dict = {headers[i]: row[i] for i in range(len(headers))}
                sheet_data.append(row_dict)
            
            logger.info(f"Lidos {len(sheet_data)} registros da planilha")
            return sheet_data
            
        except Exception as e:
            logger.error(f"Erro ao ler dados do Google Sheets: {str(e)}")
            raise
    
    def get_headers(self) -> List[str]:
        """Retorna os cabeçalhos da planilha"""
        if not self.service:
            self.authenticate()
        
        try:
            sheet = self.service.spreadsheets()
            result = sheet.values().get(
                spreadsheetId=self.sheets_id,
                range=f"{self.sheets_range.split('!')[0]}!1:1"
            ).execute()
            
            headers = result.get('values', [[]])[0]
            logger.info(f"Cabeçalhos encontrados: {headers}")
            return headers
            
        except Exception as e:
            logger.error(f"Erro ao obter cabeçalhos: {str(e)}")
            raise