import os
import time
import logging
from typing import Dict, Any
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager

logger = logging.getLogger(__name__)

class DietBoxAutomation:
    def __init__(self):
        self.driver = None
        self.wait = None
        self.dietbox_url = os.getenv('DIETBOX_URL', 'https://app.dietbox.me/login')
        self.email = os.getenv('DIETBOX_EMAIL')
        self.password = os.getenv('DIETBOX_PASSWORD')
        self.headless = os.getenv('HEADLESS_MODE', 'False').lower() == 'true'
        self.timeout = int(os.getenv('WAIT_TIMEOUT', '10'))
        
        self._setup_driver()
    
    def _setup_driver(self):
        """Configura o WebDriver Chrome"""
        chrome_options = Options()
        
        if self.headless:
            chrome_options.add_argument('--headless')
        
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        
        try:
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
        except Exception as e:
            logger.warning(f"Erro com ChromeDriverManager: {e}")
            logger.info("Tentando usar Chrome instalado no sistema...")
            self.driver = webdriver.Chrome(options=chrome_options)
        self.wait = WebDriverWait(self.driver, self.timeout)
        
        logger.info("WebDriver Chrome configurado com sucesso")
    
    def login(self):
        """Faz login no DietBox com autenticação OAuth"""
        try:
            logger.info(f"Acessando {self.dietbox_url}")
            self.driver.get(self.dietbox_url)
            
            # Aguarda redirecionamento para página de login OAuth
            time.sleep(3)
            
            # Verifica se já está na página de login ou se foi redirecionado
            current_url = self.driver.current_url
            logger.info(f"URL atual após redirecionamento: {current_url}")
            
            # Procurar e clicar no botão de login primeiro (para abrir modal/formulário)
            logger.info("🔍 Procurando botão de login...")
            login_buttons_text = [
                "Fazer login", "Login", "Entrar", "Sign in", "Fazer Login", 
                "FAZER LOGIN", "ENTRAR", "Acessar", "Acessar conta", "Acesso",
                "Para Nutricionistas", "Nutricionista", "Profissional"
            ]
            
            login_button_found = False
            
            # Primeiro tenta encontrar link/botão específico para profissionais
            for text in login_buttons_text:
                try:
                    # Tenta com links primeiro
                    link = self.driver.find_element(By.XPATH, f"//a[contains(text(), '{text}')]")
                    if link.is_displayed():
                        logger.info(f"🎯 Clicando no link: {text}")
                        link.click()
                        time.sleep(3)
                        login_button_found = True
                        break
                except:
                    try:
                        # Tenta com botões
                        button = self.driver.find_element(By.XPATH, f"//button[contains(text(), '{text}')]")
                        if button.is_displayed():
                            logger.info(f"🎯 Clicando no botão: {text}")
                            button.click()
                            time.sleep(3)
                            login_button_found = True
                            break
                    except:
                        continue
            
            # Se não encontrou, tenta por atributos comuns
            if not login_button_found:
                selectors_to_try = [
                    "a[href*='login']", "a[href*='signin']", "a[href*='auth']",
                    "button[class*='login']", "button[class*='signin']", 
                    ".login", ".signin", "#login", "#signin"
                ]
                
                for selector in selectors_to_try:
                    try:
                        element = self.driver.find_element(By.CSS_SELECTOR, selector)
                        if element.is_displayed():
                            logger.info(f"🎯 Clicando no elemento: {selector}")
                            element.click()
                            time.sleep(3)
                            login_button_found = True
                            break
                    except:
                        continue
            
            if login_button_found:
                # Aguarda redirecionamento após clique
                time.sleep(2)
                current_url = self.driver.current_url
                logger.info(f"📍 URL após clique no login: {current_url}")
            else:
                logger.warning("⚠️ Botão de login não encontrado, tentando diretamente nos campos")
            
            # Aguarda e preenche email (pode ter diferentes seletores no OAuth)
            email_selectors = [
                "#email", 
                "#signInName", 
                "input[type='email']",
                "input[name='loginfmt']",
                "#i0116"  # Microsoft login
            ]
            
            email_field = None
            for selector in email_selectors:
                try:
                    # Aguarda elemento estar presente E interativo
                    email_field = self.wait.until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    logger.info(f"Campo email encontrado com seletor: {selector}")
                    break
                except:
                    try:
                        # Se não for clicável, tenta só presença
                        email_field = self.wait.until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                        )
                        # Aguarda um pouco e tenta tornar interativo
                        time.sleep(2)
                        # Scroll para o elemento
                        self.driver.execute_script("arguments[0].scrollIntoView(true);", email_field)
                        time.sleep(1)
                        logger.info(f"Campo email encontrado com seletor: {selector}")
                        break
                    except:
                        continue
            
            if not email_field:
                raise Exception("Campo de email não encontrado")
            
            try:
                email_field.clear()
                email_field.send_keys(self.email)
                logger.info("Email preenchido com sucesso")
            except Exception as e:
                logger.warning(f"Erro ao preencher email normalmente: {e}")
                # Tenta usando JavaScript
                self.driver.execute_script(f"arguments[0].value = '{self.email}';", email_field)
                logger.info("Email preenchido via JavaScript")
            
            # Verifica se precisa clicar em "Próximo" antes da senha
            try:
                next_button = self.driver.find_element(By.ID, "idSIButton9")
                if next_button and next_button.is_enabled():
                    next_button.click()
                    time.sleep(2)
            except:
                pass
            
            # Aguarda e preenche senha
            password_selectors = [
                "#password", 
                "#pwd", 
                "input[type='password']",
                "input[name='passwd']",
                "#i0118"  # Microsoft login
            ]
            
            password_field = None
            for selector in password_selectors:
                try:
                    password_field = self.wait.until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, selector))
                    )
                    logger.info(f"Campo senha encontrado com seletor: {selector}")
                    break
                except:
                    continue
            
            if not password_field:
                raise Exception("Campo de senha não encontrado")
            
            password_field.clear()
            password_field.send_keys(self.password)
            
            # Clica no botão de login
            login_selectors = [
                "button[type='submit']",
                "#idSIButton9",  # Microsoft login
                "input[type='submit']",
                ".btn-primary",
                "#next"
            ]
            
            login_button = None
            for selector in login_selectors:
                try:
                    login_button = self.wait.until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    logger.info(f"Botão login encontrado com seletor: {selector}")
                    break
                except:
                    continue
            
            if not login_button:
                raise Exception("Botão de login não encontrado")
            
            login_button.click()
            
            # Aguarda redirecionamento (pode levar mais tempo com OAuth)
            time.sleep(5)
            
            # Verifica se login foi bem-sucedido
            success_indicators = ["dashboard", "home", "dietbox.me", "app"]
            login_success = False
            
            for indicator in success_indicators:
                if indicator in self.driver.current_url.lower():
                    login_success = True
                    break
            
            if not login_success:
                # Tenta verificar se chegou na página principal do DietBox
                try:
                    self.wait.until(
                        lambda driver: "dietbox.me" in driver.current_url and "login" not in driver.current_url
                    )
                    login_success = True
                except:
                    pass
            
            if login_success:
                logger.info("Login realizado com sucesso")
                logger.info(f"URL final: {self.driver.current_url}")
            else:
                raise Exception(f"Login falhou. URL atual: {self.driver.current_url}")
            
        except TimeoutException:
            logger.error("Timeout durante o login")
            logger.error(f"URL atual: {self.driver.current_url}")
            raise
        except Exception as e:
            logger.error(f"Erro durante o login: {str(e)}")
            logger.error(f"URL atual: {self.driver.current_url}")
            raise
    
    def navigate_to_anamnese(self):
        """Navega para a seção de anamnese"""
        try:
            # Busca por menu ou link de anamnese
            anamnese_link = self.wait.until(
                EC.element_to_be_clickable((
                    By.XPATH, 
                    "//a[contains(text(), 'Anamnese') or contains(@href, 'anamnese')]"
                ))
            )
            anamnese_link.click()
            
            time.sleep(2)  # Aguarda carregamento da página
            logger.info("Navegação para anamnese realizada")
            
        except Exception as e:
            logger.error(f"Erro ao navegar para anamnese: {str(e)}")
            raise
    
    def create_new_anamnese(self):
        """Cria nova anamnese"""
        try:
            # Busca botão de nova anamnese
            new_button = self.wait.until(
                EC.element_to_be_clickable((
                    By.XPATH, 
                    "//button[contains(text(), 'Nova') or contains(text(), 'Criar') or contains(text(), '+')]"
                ))
            )
            new_button.click()
            
            time.sleep(2)
            logger.info("Nova anamnese criada")
            
        except Exception as e:
            logger.error(f"Erro ao criar nova anamnese: {str(e)}")
            raise
    
    def fill_field(self, field_identifier: str, value: str, field_type: str = "input"):
        """Preenche um campo específico"""
        try:
            if not value or value.strip() == "":
                return
            
            if field_type == "input":
                field = self.wait.until(
                    EC.presence_of_element_located((
                        By.XPATH, 
                        f"//input[@name='{field_identifier}' or @id='{field_identifier}']"
                    ))
                )
                field.clear()
                field.send_keys(value)
                
            elif field_type == "textarea":
                field = self.wait.until(
                    EC.presence_of_element_located((
                        By.XPATH, 
                        f"//textarea[@name='{field_identifier}' or @id='{field_identifier}']"
                    ))
                )
                field.clear()
                field.send_keys(value)
                
            elif field_type == "select":
                field = self.wait.until(
                    EC.presence_of_element_located((
                        By.XPATH, 
                        f"//select[@name='{field_identifier}' or @id='{field_identifier}']"
                    ))
                )
                field.click()
                option = field.find_element(By.XPATH, f"//option[text()='{value}']")
                option.click()
            
            logger.debug(f"Campo {field_identifier} preenchido com: {value}")
            
        except Exception as e:
            logger.warning(f"Erro ao preencher campo {field_identifier}: {str(e)}")
    
    def insert_anamnese(self, data: Dict[str, Any]):
        """Insere dados de anamnese no DietBox"""
        try:
            logger.info("Iniciando inserção de dados de anamnese")
            
            # Navega para anamnese
            self.navigate_to_anamnese()
            
            # Cria nova anamnese
            self.create_new_anamnese()
            
            # Preenche campos com base no mapeamento de dados
            for field_name, field_value in data.items():
                if field_value and str(field_value).strip():
                    self.fill_field(field_name, str(field_value))
            
            # Salva a anamnese
            save_button = self.wait.until(
                EC.element_to_be_clickable((
                    By.XPATH, 
                    "//button[contains(text(), 'Salvar') or contains(text(), 'Save')]"
                ))
            )
            save_button.click()
            
            # Aguarda confirmação
            time.sleep(3)
            
            logger.info("Anamnese inserida com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inserir anamnese: {str(e)}")
            raise
    
    def close(self):
        """Fecha o WebDriver"""
        if self.driver:
            self.driver.quit()
            logger.info("WebDriver fechado")