import logging
import traceback
import time
from functools import wraps
from typing import Any, Callable

logger = logging.getLogger(__name__)

def retry_on_error(max_retries: int = 3, delay: float = 1.0, backoff: float = 2.0):
    """
    Decorator para retry automático em caso de erro
    
    Args:
        max_retries: Número máximo de tentativas
        delay: Delay inicial entre tentativas (segundos)
        backoff: Multiplicador do delay a cada tentativa
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            current_delay = delay
            last_exception = None
            
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    
                    if attempt == max_retries:
                        logger.error(f"Função {func.__name__} falhou após {max_retries} tentativas")
                        break
                    
                    logger.warning(f"Tentativa {attempt + 1} de {func.__name__} falhou: {str(e)}")
                    logger.warning(f"Tentando novamente em {current_delay} segundos...")
                    
                    time.sleep(current_delay)
                    current_delay *= backoff
            
            raise last_exception
        
        return wrapper
    return decorator

def safe_execute(func: Callable, *args, **kwargs) -> tuple[bool, Any]:
    """
    Executa função de forma segura, retornando sucesso e resultado
    
    Args:
        func: Função a ser executada
        *args: Argumentos da função
        **kwargs: Argumentos nomeados da função
        
    Returns:
        Tupla (sucesso, resultado/erro)
    """
    try:
        result = func(*args, **kwargs)
        return True, result
    except Exception as e:
        logger.error(f"Erro ao executar {func.__name__}: {str(e)}")
        logger.debug(traceback.format_exc())
        return False, e

class ErrorHandler:
    """Classe para tratamento centralizado de erros"""
    
    def __init__(self):
        self.error_counts = {}
        self.max_errors_per_type = 5
    
    def handle_error(self, error: Exception, context: str = "", critical: bool = False) -> bool:
        """
        Trata erro de forma centralizada
        
        Args:
            error: Exceção ocorrida
            context: Contexto onde ocorreu o erro
            critical: Se é um erro crítico
            
        Returns:
            True se deve continuar, False se deve parar
        """
        error_type = type(error).__name__
        error_message = str(error)
        
        # Conta erros por tipo
        if error_type not in self.error_counts:
            self.error_counts[error_type] = 0
        self.error_counts[error_type] += 1
        
        # Log do erro
        log_message = f"[{context}] {error_type}: {error_message}"
        
        if critical:
            logger.error(f"ERRO CRÍTICO - {log_message}")
            logger.error(traceback.format_exc())
            return False
        
        # Verifica se excedeu limite de erros do mesmo tipo
        if self.error_counts[error_type] > self.max_errors_per_type:
            logger.error(f"Muitos erros do tipo {error_type}. Interrompendo execução.")
            return False
        
        logger.warning(log_message)
        return True
    
    def get_error_summary(self) -> dict:
        """Retorna resumo dos erros ocorridos"""
        return self.error_counts.copy()
    
    def reset_error_counts(self):
        """Reseta contadores de erro"""
        self.error_counts.clear()

# Instância global do handler de erros
error_handler = ErrorHandler()