import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

class DataMapper:
    def __init__(self):
        # Mapeamento de campos da planilha para campos do DietBox
        # Você deve ajustar este mapeamento conforme sua planilha e DietBox
        self.field_mapping = {
            # Dados Pessoais
            'Nome': 'nome_paciente',
            'Email': 'email',
            'Telefone': 'telefone',
            'Data de Nascimento': 'data_nascimento',
            'Sexo': 'sexo',
            'Profissão': 'profissao',
            
            # Dados Antropométricos
            'Peso': 'peso',
            'Altura': 'altura',
            'Circunferência Cintura': 'circ_cintura',
            'Circunferência Quadril': 'circ_quadril',
            
            # Histórico Médico
            'Patologias': 'patologias',
            'Medicamentos': 'medicamentos',
            'Suplementos': 'suplementos',
            'Alergias': 'alergias',
            'Intolerâncias': 'intolerancias',
            
            # Hábitos Alimentares
            'Objetivo': 'objetivo',
            'Restrições Alimentares': 'restricoes',
            'Frequência Exercícios': 'freq_exercicios',
            'Hidratação': 'hidratacao',
            'Sono': 'sono',
            
            # Exames
            'Exames Recentes': 'exames_recentes',
            'Data Exames': 'data_exames',
            
            # Observações
            'Observações': 'observacoes',
            'Outras Informações': 'outras_info'
        }
    
    def map_anamnese_data(self, sheet_row: Dict[str, Any]) -> Dict[str, Any]:
        """
        Mapeia dados de uma linha da planilha para formato DietBox
        
        Args:
            sheet_row: Dicionário com dados da linha da planilha
            
        Returns:
            Dicionário com dados mapeados para DietBox
        """
        mapped_data = {}
        
        try:
            for sheet_field, dietbox_field in self.field_mapping.items():
                value = sheet_row.get(sheet_field, '').strip()
                
                if value:
                    # Aplica transformações específicas se necessário
                    mapped_value = self._transform_field_value(sheet_field, value)
                    mapped_data[dietbox_field] = mapped_value
            
            logger.debug(f"Dados mapeados: {len(mapped_data)} campos")
            return mapped_data
            
        except Exception as e:
            logger.error(f"Erro ao mapear dados: {str(e)}")
            raise
    
    def _transform_field_value(self, field_name: str, value: str) -> str:
        """
        Aplica transformações específicas nos valores dos campos
        
        Args:
            field_name: Nome do campo
            value: Valor original
            
        Returns:
            Valor transformado
        """
        # Transformações específicas por tipo de campo
        transformations = {
            'Peso': self._format_weight,
            'Altura': self._format_height,
            'Data de Nascimento': self._format_date,
            'Data Exames': self._format_date,
            'Telefone': self._format_phone,
            'Email': self._format_email,
            'Sexo': self._format_gender
        }
        
        if field_name in transformations:
            return transformations[field_name](value)
        
        return value
    
    def _format_weight(self, value: str) -> str:
        """Formata peso (remove 'kg' se presente)"""
        return value.replace('kg', '').replace(',', '.').strip()
    
    def _format_height(self, value: str) -> str:
        """Formata altura (converte para cm se necessário)"""
        value = value.replace('m', '').replace(',', '.').strip()
        
        # Se valor menor que 3, assume que está em metros
        try:
            height = float(value)
            if height < 3:
                height = height * 100  # converte para cm
            return str(int(height))
        except:
            return value
    
    def _format_date(self, value: str) -> str:
        """Formata data para padrão DD/MM/AAAA"""
        # Remove espaços e caracteres especiais
        value = value.strip().replace('-', '/').replace('.', '/')
        
        # Se já está no formato correto, retorna
        if '/' in value and len(value.split('/')) == 3:
            return value
        
        return value
    
    def _format_phone(self, value: str) -> str:
        """Formata telefone removendo caracteres especiais"""
        return ''.join(filter(str.isdigit, value))
    
    def _format_email(self, value: str) -> str:
        """Formata email (converte para minúsculo)"""
        return value.lower().strip()
    
    def _format_gender(self, value: str) -> str:
        """Padroniza gênero"""
        value = value.lower().strip()
        
        if value in ['f', 'fem', 'feminino', 'mulher']:
            return 'Feminino'
        elif value in ['m', 'masc', 'masculino', 'homem']:
            return 'Masculino'
        
        return value.title()
    
    def validate_required_fields(self, mapped_data: Dict[str, Any]) -> bool:
        """
        Valida se campos obrigatórios estão presentes
        
        Args:
            mapped_data: Dados mapeados
            
        Returns:
            True se válido, False caso contrário
        """
        required_fields = ['nome_paciente', 'email']  # Ajuste conforme necessário
        
        for field in required_fields:
            if field not in mapped_data or not mapped_data[field]:
                logger.warning(f"Campo obrigatório ausente: {field}")
                return False
        
        return True
    
    def get_field_mapping(self) -> Dict[str, str]:
        """Retorna o mapeamento de campos"""
        return self.field_mapping.copy()
    
    def add_field_mapping(self, sheet_field: str, dietbox_field: str):
        """Adiciona novo mapeamento de campo"""
        self.field_mapping[sheet_field] = dietbox_field
        logger.info(f"Mapeamento adicionado: {sheet_field} -> {dietbox_field}")
    
    def remove_field_mapping(self, sheet_field: str):
        """Remove mapeamento de campo"""
        if sheet_field in self.field_mapping:
            del self.field_mapping[sheet_field]
            logger.info(f"Mapeamento removido: {sheet_field}")