#!/usr/bin/env python3
"""
Test script to verify DietBox automation deployment locally
Run this before deploying to Render.com
"""

import requests
import json
import time
import os
import sys
from datetime import datetime

def test_local_server(port=5001):
    """Test the local Flask server"""
    base_url = f"http://localhost:{port}"
    
    print("🧪 Testing DietBox Automation Locally")
    print("=" * 40)
    
    tests = [
        ("Landing Page", f"{base_url}/", 200),
        ("Dashboard", f"{base_url}/dashboard", 200),
        ("Health Check", f"{base_url}/health", 200),
        ("API Status", f"{base_url}/api/status", 200),
        ("Check Sheets", f"{base_url}/api/check-sheets", None)  # May fail without credentials
    ]
    
    results = []
    
    for test_name, url, expected_status in tests:
        try:
            print(f"🔍 Testing {test_name}...")
            response = requests.get(url, timeout=10)
            
            if expected_status and response.status_code == expected_status:
                print(f"✅ {test_name}: OK ({response.status_code})")
                results.append((test_name, True, response.status_code))
            elif expected_status is None:
                # Special handling for endpoints that may fail
                if response.status_code in [200, 400]:  # 400 expected if no credentials
                    print(f"⚠️  {test_name}: OK with expected error ({response.status_code})")
                    results.append((test_name, True, response.status_code))
                else:
                    print(f"❌ {test_name}: Unexpected status ({response.status_code})")
                    results.append((test_name, False, response.status_code))
            else:
                print(f"❌ {test_name}: Failed ({response.status_code})")
                results.append((test_name, False, response.status_code))
                
        except requests.exceptions.ConnectionError:
            print(f"❌ {test_name}: Server not running")
            results.append((test_name, False, "Connection Error"))
        except Exception as e:
            print(f"❌ {test_name}: Error - {str(e)}")
            results.append((test_name, False, str(e)))
    
    print(f"\\n📊 Test Results Summary")
    print("=" * 40)
    
    passed = sum(1 for _, success, _ in results if success)
    total = len(results)
    
    for test_name, success, status in results:
        status_icon = "✅" if success else "❌"
        print(f"{status_icon} {test_name}: {status}")
    
    print(f"\\n🎯 Passed: {passed}/{total}")
    
    if passed == total:
        print("🚀 All tests passed! Ready for deployment.")
        return True
    else:
        print("⚠️  Some tests failed. Check your local setup.")
        return False

def check_deployment_files():
    """Check if all deployment files exist"""
    print("\\n📁 Checking Deployment Files")
    print("=" * 40)
    
    required_files = [
        "requirements.txt",
        "Procfile", 
        "runtime.txt",
        "render.yaml",
        "web_app.py",
        "templates/landing.html",
        "templates/dashboard.html"
    ]
    
    missing_files = []
    
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"✅ {file_path}")
        else:
            print(f"❌ {file_path} - MISSING")
            missing_files.append(file_path)
    
    if missing_files:
        print(f"\\n⚠️  Missing files: {', '.join(missing_files)}")
        return False
    else:
        print("\\n🎉 All deployment files present!")
        return True

def check_environment():
    """Check environment variables"""
    print("\\n🔧 Environment Variables Check")
    print("=" * 40)
    
    required_vars = [
        "DIETBOX_EMAIL",
        "DIETBOX_PASSWORD", 
        "GOOGLE_SHEETS_ID"
    ]
    
    missing_vars = []
    
    for var in required_vars:
        if os.getenv(var):
            print(f"✅ {var}: Set")
        else:
            print(f"⚠️  {var}: Not set")
            missing_vars.append(var)
    
    if missing_vars:
        print(f"\\n💡 Consider setting these for full functionality: {', '.join(missing_vars)}")
    
    return len(missing_vars) == 0

if __name__ == "__main__":
    print(f"🚀 DietBox Automation - Deployment Test")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)
    
    # Check files first
    files_ok = check_deployment_files()
    
    # Check environment
    env_ok = check_environment()
    
    # Test server if requested
    if len(sys.argv) > 1 and sys.argv[1] == "--test-server":
        port = int(sys.argv[2]) if len(sys.argv) > 2 else 5001
        server_ok = test_local_server(port)
    else:
        print("\\n💡 To test local server, run: python test_deployment.py --test-server")
        server_ok = True
    
    print("\\n" + "=" * 50)
    if files_ok and server_ok:
        print("🎉 DEPLOYMENT READY!")
        print("Next steps:")
        print("1. Push to GitHub: git push origin main")
        print("2. Deploy on Render.com")
        print("3. Set environment variables in Render")
    else:
        print("❌ Fix issues before deploying")
        sys.exit(1)