#!/usr/bin/env python3
"""
Teste de conexão com Google Sheets
"""

import os
import sys
import logging
from dotenv import load_dotenv
from src.google_sheets_reader import GoogleSheetsReader

# Carregar variáveis de ambiente
load_dotenv()

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

def test_google_sheets():
    """Testa conexão e leitura do Google Sheets"""
    try:
        logger.info("=== TESTE DE CONEXÃO GOOGLE SHEETS ===")
        
        # Verificar se arquivo credentials.json existe
        if not os.path.exists('credentials.json'):
            logger.error("❌ Arquivo credentials.json não encontrado!")
            return False
        
        # Verificar variáveis de ambiente
        sheets_id = os.getenv('GOOGLE_SHEETS_ID')
        if not sheets_id:
            logger.error("❌ GOOGLE_SHEETS_ID não configurado no .env!")
            return False
        
        logger.info(f"📊 Planilha ID: {sheets_id}")
        
        # Criar instância do leitor
        sheets_reader = GoogleSheetsReader()
        
        # Testar autenticação
        logger.info("🔐 Testando autenticação...")
        sheets_reader.authenticate()
        logger.info("✅ Autenticação realizada com sucesso!")
        
        # Testar leitura dos cabeçalhos
        logger.info("📋 Lendo cabeçalhos da planilha...")
        headers = sheets_reader.get_headers()
        logger.info(f"✅ Cabeçalhos encontrados: {headers}")
        
        # Testar leitura dos dados
        logger.info("📊 Lendo dados da planilha...")
        data = sheets_reader.read_data()
        
        if data:
            logger.info(f"✅ {len(data)} registros lidos com sucesso!")
            
            # Mostrar primeiro registro como exemplo
            if len(data) > 0:
                logger.info("📝 Primeiro registro:")
                for key, value in data[0].items():
                    logger.info(f"   {key}: {value}")
            
            return True
        else:
            logger.warning("⚠️  Nenhum dado encontrado na planilha")
            return True
            
    except FileNotFoundError as e:
        logger.error(f"❌ Arquivo não encontrado: {e}")
        return False
    except Exception as e:
        logger.error(f"❌ Erro durante teste: {str(e)}")
        return False

if __name__ == "__main__":
    success = test_google_sheets()
    
    if success:
        print("\n🎉 TESTE CONCLUÍDO COM SUCESSO!")
        print("A conexão com Google Sheets está funcionando.")
        print("Você pode executar: python main.py")
    else:
        print("\n❌ TESTE FALHOU!")
        print("Verifique a configuração antes de continuar.")
        sys.exit(1)