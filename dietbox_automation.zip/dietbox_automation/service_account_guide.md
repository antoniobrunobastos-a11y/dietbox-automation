# 🔐 Configurar Service Account (Recomendado)

## Por que Service Account?

- ✅ **Sem verificação do Google** necessária
- ✅ **Mais seguro** para aplicações web
- ✅ **Não requer login do usuário**
- ✅ **Funciona em produção** imediatamente

## 📋 Passo a Passo:

### 1. **Criar Service Account**

1. Acesse: https://console.developers.google.com/
2. Vá em **"IAM e administrador"** → **"Contas de serviço"**
3. Clique **"CRIAR CONTA DE SERVIÇO"**
4. Nome: `dietbox-automation`
5. Clique **"CRIAR E CONTINUAR"**
6. **Pular** as próximas etapas
7. Clique **"CONCLUÍDO"**

### 2. **Baixar Credenciais**

1. Clique na **conta de serviço criada**
2. Vá em **"Chaves"** → **"ADICIONAR CHAVE"** → **"Criar nova chave"**
3. Tipo: **JSON**
4. Clique **"CRIAR"**
5. Salve o arquivo como `service-account.json` na pasta do projeto

### 3. **Compartilhar Planilha**

1. Abra sua planilha Google Sheets
2. Clique **"Compartilhar"**
3. Adicione o email da service account (algo como `dietbox-automation@projeto.iam.gserviceaccount.com`)
4. Permissão: **"Visualizador"**
5. **Enviar**

### 4. **Testar**

```bash
python3 test_service_account.py
```

## 🚀 Vantagens do Service Account:

- **Zero configuração** de OAuth
- **Funciona imediatamente** em produção
- **Sem limites** de verificação do Google
- **Mais seguro** que OAuth do usuário
- **Perfeito para automação**

## 🔄 Fallback Automático

Se Service Account não funcionar, a aplicação volta automaticamente para OAuth normal.