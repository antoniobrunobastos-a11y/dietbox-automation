#!/usr/bin/env python3
"""
Automação DietBox com login manual
Para contornar problemas de OAuth, o usuário faz login manualmente
"""

import os
import time
import logging
import sys
from dotenv import load_dotenv
from src.dietbox_automation import DietBoxAutomation
from src.data_mapper import DataMapper

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def create_sample_data():
    """Dados de exemplo para teste"""
    return [
        {
            'Nome': 'Maria Silva Teste',
            'Email': 'maria.teste@email.com', 
            'Telefone': '11999999999',
            'Peso': '65',
            'Altura': '165',
            'Objetivo': 'Emagrecimento',
            'Patologias': 'Nenhuma',
            'Medicamentos': 'Nenhum'
        }
    ]

def manual_automation():
    """Executa automação com login manual"""
    print("🤖 AUTOMAÇÃO DIETBOX - MODO MANUAL")
    print("=" * 50)
    
    automation = None
    
    try:
        # Inicializar automação
        automation = DietBoxAutomation()
        data_mapper = DataMapper()
        
        print("🌐 Abrindo navegador...")
        automation.driver.get("https://dietbox.me")
        
        print("\n" + "="*50)
        print("🔐 FAÇA LOGIN MANUALMENTE:")
        print("1. O navegador está aberto na página do DietBox")
        print("2. Faça seu login normalmente")
        print("3. Navegue até onde você adiciona anamneses")
        print("4. Volte aqui e pressione ENTER para continuar")
        print("="*50)
        
        # Aguarda usuário fazer login manual
        input("👆 Pressione ENTER após fazer login e estar na página de anamneses...")
        
        # Pegar dados de exemplo
        sample_data = create_sample_data()
        
        print(f"\n📊 Processando {len(sample_data)} registros de teste...")
        
        for i, row_data in enumerate(sample_data, 1):
            try:
                print(f"\n🔄 Processando registro {i}...")
                
                # Mapear dados
                mapped_data = data_mapper.map_anamnese_data(row_data)
                
                print("📝 Dados mapeados:")
                for field, value in mapped_data.items():
                    print(f"   {field}: {value}")
                
                print("\n🎯 INSTRUÇÕES:")
                print("1. Crie uma nova anamnese manualmente no DietBox")
                print("2. Os campos serão preenchidos automaticamente")
                print("3. Verifique se os dados estão corretos")
                print("4. Salve manualmente se estiver tudo ok")
                
                input("👆 Pressione ENTER quando estiver pronto para preencher os campos...")
                
                # Tentar preencher campos automaticamente
                success_count = 0
                
                for field_name, field_value in mapped_data.items():
                    try:
                        # Tenta diferentes seletores para o campo
                        selectors = [
                            f"input[name='{field_name}']",
                            f"#{field_name}",
                            f"input[id='{field_name}']",
                            f"textarea[name='{field_name}']",
                            f"select[name='{field_name}']"
                        ]
                        
                        field_found = False
                        for selector in selectors:
                            try:
                                element = automation.driver.find_element("css selector", selector)
                                if element.is_displayed():
                                    # Tenta preencher o campo
                                    if element.tag_name.lower() == 'select':
                                        # Para selects, tenta encontrar a opção
                                        options = element.find_elements("tag name", "option")
                                        for option in options:
                                            if str(field_value).lower() in option.text.lower():
                                                option.click()
                                                break
                                    else:
                                        # Para inputs e textareas
                                        element.clear()
                                        element.send_keys(str(field_value))
                                    
                                    print(f"✅ {field_name}: {field_value}")
                                    success_count += 1
                                    field_found = True
                                    break
                            except:
                                continue
                        
                        if not field_found:
                            print(f"⚠️  Campo não encontrado: {field_name}")
                            
                    except Exception as e:
                        print(f"❌ Erro ao preencher {field_name}: {e}")
                
                print(f"\n📊 Resultado: {success_count} campos preenchidos automaticamente")
                
                user_input = input("✅ Salvar este registro? (s/N): ").lower()
                
                if user_input == 's':
                    print("💾 Salvando registro...")
                    # Tenta clicar em botão de salvar
                    save_selectors = [
                        "button:contains('Salvar')",
                        "button:contains('Save')",
                        "input[type='submit']",
                        ".btn-save",
                        "#save"
                    ]
                    
                    saved = False
                    for selector in save_selectors:
                        try:
                            save_btn = automation.driver.find_element("css selector", selector)
                            if save_btn.is_displayed():
                                save_btn.click()
                                print("✅ Registro salvo!")
                                saved = True
                                break
                        except:
                            continue
                    
                    if not saved:
                        print("⚠️  Botão de salvar não encontrado - salve manualmente")
                else:
                    print("⏭️  Registro pulado")
                
                time.sleep(2)
                
            except Exception as e:
                print(f"❌ Erro ao processar registro {i}: {e}")
                continue
        
        print("\n🎉 AUTOMAÇÃO CONCLUÍDA!")
        print("🔍 Verifique os registros no DietBox")
        
        input("👆 Pressione ENTER para fechar o navegador...")
        
    except Exception as e:
        print(f"❌ Erro geral: {e}")
    finally:
        if automation:
            automation.close()

if __name__ == "__main__":
    manual_automation()